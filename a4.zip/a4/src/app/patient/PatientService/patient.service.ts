import { Injectable,Inject } from '@angular/core';
import { Http, Headers, Response ,RequestOptions} from '@angular/http';
import { appConfig } from "../../core/config/app.config";
import {Observable} from 'rxjs/Rx';
import { AuthService } from "../../core/services/auth.service"; 
@Injectable()
export class PatientService
{    public headers:Headers;
     constructor( @Inject(Http) public http: Http,private authenticationService: AuthService)
    {
       this.headers = new Headers({ 'Authorization': 'Bearer ' + authenticationService.token });
       this.headers.append('Content-Type', 'application/json') //******
    }
  getPatientList() {
    console.log("Service Calling");
    return this.http.get(appConfig.apiUrl+ `api/get`)
     .map((res:Response) => 
    {
      console.log("getPatientList",res);
        var obj = res.json();
        console.log("getPatientList",obj);
        var list = obj.data;
         console.log("getPatientList",list);
        return list;
    });
}
//  deleteUsers: function(id) {
//             return $resource(APP_CONST.API_URL + "/task/" + id);
//         },
deletePatient(id){
  console.log("delete service calling");
  return this.http.delete(appConfig.apiUrl+`api/delete/`+id)
    .map((res:Response) => res.json());
}

  savePatient(d:any){
    console.log("save patient");
  //  return this.http.post(appConfig.apiUrl+'api/Patient/AddUpdatePatient')
     return this.http.post(appConfig.apiUrl+`api/signup`, JSON.stringify(d), { headers: this.headers })
    .map((res:Response) => res.json());
  }
getPatientById(id:number){
  console.log("getPatientById",id);
   return this.http.get(appConfig.apiUrl+ `api/getById/`+id)
     .map((res:Response) => res.json());
    }



updatePatient(id,data){
  console.log("id-------->",id)
    console.log("update patient");
     return this.http.post(appConfig.apiUrl+`api/update/`+id, JSON.stringify(data), { headers: this.headers })
    .map((res:Response) => res.json());
  }

}
