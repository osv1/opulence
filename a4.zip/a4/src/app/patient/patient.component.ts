import { Component } from '@angular/core';

@Component({
  selector: 'app-patient',
  template:`
  <router-outlet></router-outlet>
  `,
 
})
export class PatientComponent {
  title = 'app works!';
}
