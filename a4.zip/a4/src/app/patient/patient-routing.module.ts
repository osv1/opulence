import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import {PatientListingComponent} from "./components/patient-listing/patient-listing.component"
import { PatientComponent } from "./patient.component";
import {PatientRegistrationComponent} from "./components/patient-registration/patient-registration.component";
import{PatientUpdateComponent} from "./components/patient-update/patient-update.component"


  const routes: Routes = [
     {
         path: '',
         component: PatientComponent,
         children: [
              { path: '', component: PatientListingComponent },
              { path: 'addpatient', component: PatientRegistrationComponent },
              { path:'updatepatient/:id',component: PatientUpdateComponent}
          ]
     }
 ];  

 @NgModule({
     imports: [RouterModule.forChild(routes)],
     exports: [RouterModule]
 }) 
export class PatientRoutingModule {

}