import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {ToasterModule, ToasterService} from 'angular2-toaster';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, } from '@angular/forms';
import { ActivatedRoute,Router,ParamMap } from "@angular/router";
import { ReactiveFormsModule,NgModel } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { PatientService } from "../../PatientService/patient.service";
import { commonService } from "../../../core/services/common.service";
import { Message } from "primeng/primeng";
import 'rxjs/add/operator/switchMap';
import { DateTimeUtility } from "../../../core/utility/datetime.utility";



@Component({
  selector: 'patient-registration',
  templateUrl: './patient-registration.component.html',
  styleUrls: ['./patient-registration.component.css'],
  providers: [PatientService,commonService,ToasterService],

})

 export class PatientRegistrationComponent implements OnInit {
  Router: any;
  PatientRegistrationForm: FormGroup;
  DateOfBirth:Date;
  msgs: Message[];
  
  constructor(public router: Router,
     private route: ActivatedRoute,
     private dateTimeUtility: DateTimeUtility,
     private patientService: PatientService,
     private CommonService:commonService,
     private toastr: ToastrService,
     private toasterService: ToasterService,
     public fb: FormBuilder){this.createForm(); }
  
  ngOnInit(){
}

  public CountryList: any[];
  public val = {};
  private createForm() {

    this.PatientRegistrationForm = this.fb.group({
        firstname: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
        // firstname: new FormControl('', Validators.required),
        middleName:['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
        lastname:['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
        mobileNo:['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
        email:['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
        DOB: new FormControl('',Validators.required),
        State:['', [Validators.required]],
        District: new FormControl('',Validators.required),
        City: new FormControl('',Validators.required)

});

  }


  save(){
    
     var patientData = this.PatientRegistrationForm.value;  
     console.log("patientData",patientData);
      patientData.DOB = this.dateTimeUtility.format(patientData.DOB);
      console.log("patientData",patientData);
      if (this.PatientRegistrationForm.invalid) {
      Object.keys(this.PatientRegistrationForm.controls).forEach((formControl: any) => {
        this.PatientRegistrationForm.controls[formControl].markAsDirty()
      })
    } else {
      this.patientService.savePatient(patientData).subscribe(data => {
              this.toastr.success('Patient Register SuccessFully');        
                    this.router.navigate(['app/patient'])
                }
      )}
  }
  
 }






