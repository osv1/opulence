import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, } from '@angular/forms';
import { Router, ActivatedRoute, Params, ParamMap } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { PatientService } from "../../PatientService/patient.service";
import { commonService } from "../../../core/services/common.service";
import { appConfig } from "../../../core/config/app.config";
import { Http, RequestOptions, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Message } from "primeng/primeng";
import { ToastrService } from 'ngx-toastr';
import 'rxjs/add/operator/switchMap';
import { DomSanitizer } from '@angular/platform-browser';
import { DateTimeUtility } from "../../../core/utility/datetime.utility";
interface paginationModel {
    Page: number,
    Limit: number,
    Name: string,
    Date: Date,
    RecordID: string
}
@Component({
    selector: 'patient-update',
    templateUrl: './patient-update.component.html',
    styleUrls: ['./patient-update.component.css'],
    providers: [PatientService, commonService],

})

export class PatientUpdateComponent implements OnInit {
    msgs: Message[];
    DateOfBirth: Date;
    PatientRegistrationForm: FormGroup;
    constructor(private route: ActivatedRoute, public router: Router,
        private patientService: PatientService,
        private dateTimeUtility: DateTimeUtility,
        private sanitizer: DomSanitizer,
        private CommonService: commonService,
        private toastr: ToastrService,
        public fb: FormBuilder,
        private http: Http
    ) {

        this.createForm();

    }

    ngOnInit() {
        var routeparam = this.route;
        this.route.params.subscribe((params: Params) => {
            let userId = params['id'];
            this.patientService.getPatientById(userId).subscribe((data: any) => {
                console.log("data", data);
                this.PatientRegistrationForm.patchValue({
                    _id: data.data._id,
                    firstname: data.data.firstname,
                    middleName: data.data.middleName,
                    lastname: data.data.lastname,
                    mobileNo: data.data.mobileNo,
                    email: data.data.email,
                    State: data.data.State,
                    District: data.data.District,
                    City: data.data.City,
                    DOB: new Date(data.data.DOB),

                });
            },

                err => console.error(err),
                () => { }
            );
        }
        );
    }
    public NameList: any[];
    public val = {};
    private createForm() {

        this.PatientRegistrationForm = this.fb.group({
            _id: new FormControl(''),
            firstname: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
            middleName: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
            lastname: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
            mobileNo: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
            email: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(40)]],
            DOB: new FormControl('', Validators.required),
            State: ['', [Validators.required]],
            District: new FormControl('', Validators.required),
            City: new FormControl('', Validators.required)

        });
    }

    save() {
console.log("save")
        var patientData = this.PatientRegistrationForm.value;
        patientData.DOB = this.dateTimeUtility.format(patientData.DOB);
        console.log("patientData", patientData);
        if (this.PatientRegistrationForm.invalid) {
            console.log("patientData", this.PatientRegistrationForm.invalid);
            Object.keys(this.PatientRegistrationForm.controls).forEach((formControl: any) => {
                this.PatientRegistrationForm.controls[formControl].markAsDirty()
            })
        } else {
            console.log("patientData-------------->>>",patientData)
            this.patientService.updatePatient(patientData._id,patientData ).subscribe(data => {
                this.toastr.success('Update Info. SuccessFully');
                this.router.navigate(['app/patient'])
            }
            )
        }
    }


}









