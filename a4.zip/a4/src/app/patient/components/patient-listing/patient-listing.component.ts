import { Component, OnInit } from '@angular/core';
import { PatientService } from '../../PatientService/patient.service'
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-patient-listing',
  templateUrl: './patient-listing.component.html',
  styleUrls: ['./patient-listing.component.css']
})
export class PatientListingComponent implements OnInit {

  constructor(
    private toastr: ToastrService,
    private patientService: PatientService) {
   
    this.loadPatientList();
  }

  ngOnInit() {
  }
  public patientList: any[];

  loadPatientList() {
    console.log("Controller Calling");
    this.patientService.getPatientList().subscribe(
      data => { 
        console.log("Data retrive",data);
        this.patientList = data },
      err => console.error(err),
      () => { }
    );
  }
   deletePatient(id) {
    console.log("deletePatient Calling");
    this.patientService.deletePatient(id).subscribe(
      data => { 
        this.loadPatientList(); },
      err => console.error(err),
      () => {
        this.toastr.success('Patient Deleted SuccessFully');
      }
    );
  }
}

