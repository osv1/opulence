import { NgModule } from "@angular/core/";
import { CommonModule } from "@angular/common";
import { ToasterService } from '../core/services/toaster.service';
import { PatientListingComponent } from "./components/patient-listing/patient-listing.component";
import { PatientUpdateComponent } from "./components/patient-update/patient-update.component"
import { PatientRoutingModule } from "./patient-routing.module"
import { PatientRegistrationComponent } from "./components/patient-registration/patient-registration.component";
// import { PatientListingModule } from "../patient/components/patient-listing/patient-listing.module";

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PatientService } from "./PatientService/patient.service";
import { PatientComponent } from "./patient.component";
import {CalendarModule} from 'primeng/primeng';
import { commonService } from "../core/services/common.service";

import {FileUploadModule} from 'primeng/primeng';
import {GrowlModule,Message} from 'primeng/primeng';

@NgModule({
    imports: [
        CommonModule,
        PatientRoutingModule,
        ReactiveFormsModule,
        FormsModule,
        CalendarModule,
        FileUploadModule,
        GrowlModule,
    ],
    declarations: [
        PatientComponent,
        PatientListingComponent,
        PatientRegistrationComponent,
        PatientUpdateComponent
    ],
    providers: [PatientService,commonService,ToasterService]
})
export class PatientModules {

}
