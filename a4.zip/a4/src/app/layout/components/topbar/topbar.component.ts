import { Component } from "@angular/core";

@Component({
    selector: 'topbar-component',
    templateUrl: 'topbar.component.html',
     styleUrls: ['topbar.component.css']  
   //  D:\DayUsers\Mukesh K\Projects\DSHU.PI\SDHP-Design\src\app\layout\components\topbar\topbar.coponent.css
})
export class TopBarComponent {

}
