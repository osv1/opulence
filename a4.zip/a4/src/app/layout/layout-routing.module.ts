import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LayoutComponent } from "./layout.component";


const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [           
            {
                path: 'patient',
                loadChildren: './../patient/patient.module#PatientModules'
               
            },
            {
                path: 'professional',
                loadChildren: './../professional/professional.module#ProfessionalModule'
            },  
            {
                path: 'orientation',
                loadChildren: './../orientation/orientation.module#OrientationModules'
            }



        ]
       
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule {

}