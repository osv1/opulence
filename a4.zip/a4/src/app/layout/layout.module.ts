import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";

import { LayoutRoutingModule } from "../layout/layout-routing.module";
import { LayoutComponent } from "./layout.component";
import { SideBarComponent } from "./components/sidebar/sidebar.component";
import { FooterComponent } from "./components/footer/footer.component";
import { TopBarComponent } from "./components/topbar/topbar.component";

// import { HeaderComponent } from "app/layout/components/header/header.component";
// import { SidebarComponent } from "app/layout/components/aside/aside.component";
//import { MyFormModule } from "./forms/forms.module";
//import {PatientModules} from "../patient/patient.module"

import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        LayoutRoutingModule,
        ReactiveFormsModule
    ],
    declarations: [LayoutComponent, SideBarComponent, FooterComponent, TopBarComponent],
    providers: []
})
export class LayoutModule {

}