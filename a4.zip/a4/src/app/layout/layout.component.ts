import { Component } from "@angular/core";

@Component({
    template: `
            <div id="wrapper">
                <topbar-component></topbar-component>
                <div class="container-fluid">
                    <div class="row">
                        <sidebar-component></sidebar-component>
                        <main >
                            <router-outlet></router-outlet>
                     </main>
                     
                    </div> 

                </div>
                <footer-component></footer-component> 
            </div>
    `,
    styles: []
})
export class LayoutComponent {

}