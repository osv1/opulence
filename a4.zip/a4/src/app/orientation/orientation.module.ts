import { NgModule } from "@angular/core/";
import { CommonModule } from "@angular/common";
import { OrientationAddsupplementComponent } from "./components/orientation-addsupplement/orientation-addsupplement.component";
import { OrientationListingComponent } from "./components/orientation-listing/orientation-listing.component";
import { OrientationRoutingModule } from "./orientation-routing.module"
// import { OrientationAddsupplementComponent } from "./components/orientation-addsupplement/orientation-addsupplement.component";
// import { PatientListingModule } from "../patient/components/patient-listing/patient-listing.module";

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { OrientationService } from "./OrientationService/orientation.service";
import { OrientationComponent } from "./orientation.component";
import {CalendarModule} from 'primeng/primeng';
import { commonService } from "../core/services/common.service";

import {FileUploadModule} from 'primeng/primeng';
import {GrowlModule,Message} from 'primeng/primeng';
import { OrientationAddHabitComponent } from "./components/orientation-add-habit/orientation-add-habit.component"
import { OrientationAddExcerciseComponent } from "./components/orientation-add-excercise/orientation-add-excercise.component";
import { OrientationAddDietComponent } from "./components/orientation-add-diet/orientation-add-diet.component";
import { OrientationAddEmotionalComponent } from "./components/orientation-add-emotional/orientation-add-emotional.component";
import { OrientationAddMedicationComponent } from "./components/orientation-add-medication/orientation-add-medication.component";
@NgModule({
    imports: [
        CommonModule,
        OrientationRoutingModule,
        ReactiveFormsModule,
        FormsModule,
        CalendarModule,
      //  PatientListingModule
      FileUploadModule,
      GrowlModule,
    ],
    declarations: [
        OrientationComponent,
        OrientationAddsupplementComponent,
        OrientationListingComponent,
        OrientationAddHabitComponent,
        OrientationAddExcerciseComponent,
        OrientationAddDietComponent,
        OrientationAddEmotionalComponent,
        OrientationAddMedicationComponent


    ],
    providers: [OrientationService,commonService]
})
export class OrientationModules {

}
