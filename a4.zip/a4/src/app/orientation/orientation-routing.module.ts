import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
//import {PatientListingComponent} from "./components/patient-listing/patient-listing.component"
import { OrientationComponent } from "./orientation.component";
import { OrientationAddsupplementComponent } from "./components/orientation-addsupplement/orientation-addsupplement.component";
import { OrientationListingComponent } from "./components/orientation-listing/orientation-listing.component";
import { OrientationAddHabitComponent } from "./components/orientation-add-habit/orientation-add-habit.component";
import { OrientationAddExcerciseComponent } from "./components/orientation-add-excercise/orientation-add-excercise.component";
import { OrientationAddDietComponent } from "./components/orientation-add-diet/orientation-add-diet.component";
import { OrientationAddEmotionalComponent } from "./components/orientation-add-emotional/orientation-add-emotional.component";
import { OrientationAddMedicationComponent } from "./components/orientation-add-medication/orientation-add-medication.component";




  const routes: Routes = [
     {
         path: '',
         component: OrientationComponent,
         children: [
              { path: '', component: OrientationListingComponent },
             { path: 'addfillorientation', component: OrientationAddsupplementComponent },
             { path: 'addfillhabit', component: OrientationAddHabitComponent },
             { path: 'addfillexcercise', component: OrientationAddExcerciseComponent },
             { path: 'addfilldiet', component: OrientationAddDietComponent },
             { path: 'addfillemotional', component: OrientationAddEmotionalComponent },
             { path: 'addfillmedication', component: OrientationAddMedicationComponent }
          ]
     }
 ];  

 @NgModule({
     imports: [RouterModule.forChild(routes)],
     exports: [RouterModule]
 }) 
export class OrientationRoutingModule {

}