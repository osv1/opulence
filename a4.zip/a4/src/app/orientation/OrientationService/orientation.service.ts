import { Injectable,Inject } from '@angular/core';
import { Http, Headers, Response ,RequestOptions} from '@angular/http';
import { appConfig } from "../../core/config/app.config";
import {Observable} from 'rxjs/Rx';
import { AuthService } from "../../core/services/auth.service"; 
@Injectable()
export class OrientationService
{    public headers:Headers;
     constructor( @Inject(Http) public http: Http,private authenticationService: AuthService)
    {
       this.headers = new Headers({ 'Authorization': 'Bearer ' + authenticationService.token });
       this.headers.append('Content-Type', 'application/json') //******
    }
  getOrientationList() {
    return this.http.get(appConfig.apiUrl+ `api/PatientOrientation/GetPatientOrientationList`)
     .map((res:Response) => 
    {
        var obj = res.json();
        var list = obj.response;
        return list;
    }   

     );
}
  saveOrientation(d:any){
  //  return this.http.post(appConfig.apiUrl+'api/Patient/AddUpdatePatient')
     return this.http.post(appConfig.apiUrl+`/api/PatientOrientation/AddUpdatePatientOrientationControl`, JSON.stringify(d), { headers: this.headers })
    .map((res:Response) => res.json());
  }
}
