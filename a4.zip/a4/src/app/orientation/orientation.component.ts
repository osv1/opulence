import { Component } from '@angular/core';

@Component({
  selector: 'app-orientation',
   template:`
  <router-outlet></router-outlet>
  `,
  styleUrls: ['./orientation.component.css']
})
export class OrientationComponent {

  title = 'app works!';

}
