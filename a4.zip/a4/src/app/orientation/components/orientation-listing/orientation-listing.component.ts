import { Component, OnInit } from '@angular/core';
import { OrientationService } from '../../OrientationService/orientation.service'

@Component({
  selector: 'app-orientation-listing',
  templateUrl: './orientation-listing.component.html',
  styleUrls: ['./orientation-listing.component.css']
})
export class OrientationListingComponent implements OnInit {

  constructor(private orientationService: OrientationService) {
   
    this.loadorientationList();
  }

  ngOnInit() {
  }
  public orientationList: any[];

  loadorientationList() {
    this.orientationService.getOrientationList().subscribe(
      data => { this.orientationList = data },
      err => console.error(err),
      () => { }
    );
  }
}

