import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationListingComponent } from './orientation-listing.component';

describe('OrientationListingComponent', () => {
  let component: OrientationListingComponent;
  let fixture: ComponentFixture<OrientationListingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationListingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
