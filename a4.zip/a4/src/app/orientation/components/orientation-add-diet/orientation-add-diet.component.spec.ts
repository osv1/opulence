import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationAddDietComponent } from './orientation-add-diet.component';

describe('OrientationAddDietComponent', () => {
  let component: OrientationAddDietComponent;
  let fixture: ComponentFixture<OrientationAddDietComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationAddDietComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationAddDietComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
