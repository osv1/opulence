import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, } from '@angular/forms';

//import { FormsModule,FormGroup,FormBuilder, FormControl,Validators,ReactiveFormsModule  } from '@angular/forms';
import { Router } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { OrientationService } from "../../OrientationService/orientation.service";
import { commonService } from "../../../core/services/common.service";
import { Message } from "primeng/primeng";

interface orientationDemograph {
  orientationType: string,
  number: string,
  timesFrequency:string,
  duration:string
}

@Component({
  selector: 'app-orientation-add-habit',
  templateUrl: './orientation-add-habit.component.html',
  styleUrls: ['./orientation-add-habit.component.css'],
  providers: [OrientationService,commonService],
})
export class OrientationAddHabitComponent implements OnInit {
 OrientationForm: FormGroup;
  DateOfBirth:Date;
  msgs: Message[];
  constructor(public router: Router,
     private orientationService: OrientationService,
     private CommonService:commonService,
     public fb: FormBuilder) {

    this.createForm();
   // this.loadCountryList();
  }
  ngOnInit() {

  }
  public CountryList: any[];
  public val = {};
  private createForm() {

    this.OrientationForm = this.fb.group({
        orientationType: new FormControl('', Validators.required),
        number: new FormControl('', Validators.required),
        timesFrequency: new FormControl(''),
        duration: new FormControl(''),
      })
 }

  save() {
    let val = this.OrientationForm.value;
    let prop: orientationDemograph = {
      orientationType: this.OrientationForm.value.orientationType,
      number: this.OrientationForm.value.number,
      timesFrequency: this.OrientationForm.value.timesFrequency,
      duration: this.OrientationForm.value.duration
    };
 
    console.log(prop);

    this.orientationService.saveOrientation(prop).subscribe(
      d => { this.router.navigate(['app/orientation']) },
      err => console.error(err),
      () => { console.log("Done") }
    );

  }

  // msgs: Message[];
  

  }


