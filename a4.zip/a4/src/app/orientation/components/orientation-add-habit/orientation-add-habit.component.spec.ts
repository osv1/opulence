import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationAddHabitComponent } from './orientation-add-habit.component';

describe('OrientationAddHabitComponent', () => {
  let component: OrientationAddHabitComponent;
  let fixture: ComponentFixture<OrientationAddHabitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationAddHabitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationAddHabitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
