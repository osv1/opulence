import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationAddExcerciseComponent } from './orientation-add-excercise.component';

describe('OrientationAddExcerciseComponent', () => {
  let component: OrientationAddExcerciseComponent;
  let fixture: ComponentFixture<OrientationAddExcerciseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationAddExcerciseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationAddExcerciseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
