import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationAddMedicationComponent } from './orientation-add-medication.component';

describe('OrientationAddMedicationComponent', () => {
  let component: OrientationAddMedicationComponent;
  let fixture: ComponentFixture<OrientationAddMedicationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationAddMedicationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationAddMedicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
