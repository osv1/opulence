import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationAddEmotionalComponent } from './orientation-add-emotional.component';

describe('OrientationAddEmotionalComponent', () => {
  let component: OrientationAddEmotionalComponent;
  let fixture: ComponentFixture<OrientationAddEmotionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationAddEmotionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationAddEmotionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
