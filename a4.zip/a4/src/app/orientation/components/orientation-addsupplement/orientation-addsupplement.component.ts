import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, } from '@angular/forms';

//import { FormsModule,FormGroup,FormBuilder, FormControl,Validators,ReactiveFormsModule  } from '@angular/forms';
import { Router } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { OrientationService } from "../../OrientationService/orientation.service";
import { commonService } from "../../../core/services/common.service";
import { Message } from "primeng/primeng";

interface orientationDemograph {
  orientationType: string,
  at: string,
  quantity: string,
  timesFrequency:string

}

@Component({
  selector: 'app-orientation-addsupplement',
  templateUrl: './orientation-addsupplement.component.html',
  styleUrls: ['./orientation-addsupplement.component.css'],
   providers: [OrientationService,commonService],
})

  export class OrientationAddsupplementComponent implements OnInit {
  OrientationForm: FormGroup;
  DateOfBirth:Date;
  msgs: Message[];
  constructor(public router: Router,
     private orientationService: OrientationService,
     private CommonService:commonService,
     public fb: FormBuilder) {

    this.createForm();
   // this.loadCountryList();
  }
  ngOnInit() {

  }
  public CountryList: any[];
  public val = {};
  private createForm() {

    this.OrientationForm = this.fb.group({
        orientationType: new FormControl('', Validators.required),
        at: new FormControl('', Validators.required),
        quantity: new FormControl(''),
        timesFrequency: new FormControl('')
      })
 }

  save() {
    let val = this.OrientationForm.value;
    let prop: orientationDemograph = {
      
      orientationType: this.OrientationForm.value.orientationType,
     at: this.OrientationForm.value.at,
      quantity: this.OrientationForm.value.quantity,
      timesFrequency: this.OrientationForm.value.timesFrequency
    };
 
    console.log(prop);

    this.orientationService.saveOrientation(prop).subscribe(
      d => { this.router.navigate(['app/orientation']) },
      err => console.error(err),
      () => { console.log("Done") }
    );

  }

  // msgs: Message[];
  

  }

