import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrientationAddsupplementComponent } from './orientation-addsupplement.component';

describe('OrientationAddsupplementComponent', () => {
  let component: OrientationAddsupplementComponent;
  let fixture: ComponentFixture<OrientationAddsupplementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrientationAddsupplementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrientationAddsupplementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
