import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from "@angular/router";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome/angular-font-awesome';
import {  ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '@angular/material';
import { AppRoutingModule } from "./app-routing.module";
import { PageNotFountComponent } from "./pagenotfound.component";
import { AuthGuard } from "./core/guards/auth.guard";
import { AuthService } from "./core/services/auth.service";
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { DateTimeUtility } from "./core/utility/datetime.utility";


@NgModule({
  declarations: [
    PageNotFountComponent,
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule,
    HttpModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({ 
    timeOut: 6000,
    positionClass: 'toast-bottom-right',
    preventDuplicates: true,
  }),
    AngularFontAwesomeModule,
    ReactiveFormsModule
  ],
  providers: [
    AuthGuard,
    AuthService,
    DateTimeUtility
             ],
  bootstrap: [AppComponent]
})
export class AppModule { }




