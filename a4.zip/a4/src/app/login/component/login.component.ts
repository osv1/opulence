import { Component,OnInit } from "@angular/core";
import { FormsModule,FormGroup,FormBuilder, FormControl,Validators } from '@angular/forms';
import { AuthService } from "../../core/services/auth.service";
import { Router } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit  {
  
    LoginForm: FormGroup;
      message: string;
      redirectUrl:string;
      constructor(public authService: AuthService, public router: Router) {
          debugger;
          this.setMessage();
      }
  
      ngOnInit() {
        this.createForm();
      }

      private createForm() {
        this.LoginForm = new FormGroup({
          UserName: new FormControl('', Validators.required),
          Password: new FormControl('', Validators.required),
          
        });
      }

      setMessage() {
          this.message = 'Logged ' + (this.authService.isLoggedIn ? 'in' : 'out');
      }
  
      login(LoginForm:any) {
          debugger;
          this.message = 'Trying to log in ...';
          console.log(this.LoginForm.value);
  
          this.authService.login(this.LoginForm.value)
          .subscribe(result=> {
              this.setMessage();
              if (this.authService.isLoggedIn) {
                  this.router.navigate(['app/patient']);
              }
          });
      }
  }
