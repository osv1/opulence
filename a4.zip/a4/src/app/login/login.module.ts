import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { LoginRoutingModule } from "../login/login-routing.module";
import { LoginComponent } from "../login/component/login.component";
//import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'



@NgModule({
    imports: [CommonModule, LoginRoutingModule,ReactiveFormsModule,NgbModule],
    declarations: [LoginComponent],
    providers: []
})
export class LoginModule {

}