import { NgModule } from "@angular/core/";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {ProfessionalRoutingModule} from "../professional/professional-routing.module";
import {BusinessControlComponent} from "../professional/components/BusinessControl/Business Control Menu/BusinessControl.component";
import {BusinessControllistingComponent} from "../professional/components/BusinessControl/Business Control Listing/BusinessControl-listing.component";
import { ProfessionalComponent } from "./professional.component";
import { BusinessCtrlService } from "./businessCtrlServices/businessCtrlServices";
import { BusinessCtrlAppointmentCancellationComponent } from "./components/BusinessControl/Business Control Menu/BusinessControlCancellation.component";
import { PatientNoScheduleComponent } from "./components/BusinessControl/Business Control Menu/PatientNoschedule.component";

import {CalendarModule} from 'primeng/primeng';
import { commonService } from "../core/services/common.service";
import { BusinessCtrlClinicalProcedureComponent } from "./components/BusinessControl/Business Control Menu/BusinessControlClinicalProcedure.component";
import { BusinessCtrlClinicalFreeProcedureComponent } from "./components/BusinessControl/Business Control Menu/BusinessControlClinicalFreeProcedure.component ";
import { AddsupplementComponent } from "./components/OrientationControl/addsupplement/addsupplement.component";

//import { BusinessCtrlService} from ""
@NgModule({
    imports: [
        CommonModule,
        ProfessionalRoutingModule,
         ReactiveFormsModule,
        FormsModule,
        CalendarModule
    ],
    declarations: [
        BusinessControlComponent,
        BusinessControllistingComponent,
        BusinessCtrlAppointmentCancellationComponent,
        PatientNoScheduleComponent,
        BusinessCtrlClinicalProcedureComponent,
        BusinessCtrlClinicalFreeProcedureComponent,
        ProfessionalComponent,
        AddsupplementComponent
    ],
    providers: [BusinessCtrlService,commonService]
})
export class ProfessionalModule {

}
