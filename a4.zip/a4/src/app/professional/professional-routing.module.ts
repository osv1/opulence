import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";


import { BusinessControlComponent } from "../professional/components/BusinessControl/Business Control Menu/BusinessControl.component"
import { BusinessControllistingComponent } from "../professional/components/BusinessControl/Business Control Listing/BusinessControl-listing.component"
import { ProfessionalComponent } from "./professional.component";
import { BusinessCtrlAppointmentCancellationComponent } from "./components/BusinessControl/Business Control Menu/BusinessControlCancellation.component";
import { PatientNoScheduleComponent } from "./components/BusinessControl/Business Control Menu/PatientNoschedule.component";
import { BusinessCtrlClinicalProcedureComponent } from "./components/BusinessControl/Business Control Menu/BusinessControlClinicalProcedure.component";
import { BusinessCtrlClinicalFreeProcedureComponent } from "./components/BusinessControl/Business Control Menu/BusinessControlClinicalFreeProcedure.component ";
import { AddsupplementComponent } from "./components/OrientationControl/addsupplement/addsupplement.component";


const routes: Routes = [
    {
        path: '',
        component: ProfessionalComponent,
        children: [
            { path: '', component: BusinessControllistingComponent },
            { path: 'BusinessControl', component: BusinessControlComponent },
            { path: 'CancelAppointment', component: BusinessCtrlAppointmentCancellationComponent },
            { path: 'NoSchedule', component: PatientNoScheduleComponent },
            { path: 'ClinicalProcedure', component: BusinessCtrlClinicalProcedureComponent },
            { path: 'FreeProcedure', component: BusinessCtrlClinicalFreeProcedureComponent },
            { path: 'OrientationControl', component: AddsupplementComponent },
            
            //
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ProfessionalRoutingModule {

}