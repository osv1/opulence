import { Component, OnInit } from '@angular/core';
//import { BusinessCtrlService } from "../../../businessCtrlServices/businessCtrlServices";
import { BusinessCtrlService } from "../../../businessCtrlServices/businessCtrlServices";
//import { BusinessCtrlService } from "../../businessCtrlServices/businessCtrlServices";
import { Http, Headers, Response ,RequestOptions} from '@angular/http';

@Component({
  selector: 'app-businessControl-listing',
  templateUrl: './BusinessControl-listing.component.html',
  styleUrls: ['./BusinessControl-listing.component.css']
})


//app\professional\components\BusinessControl\Business Control Listing\BusinessControl-listing.component.html

export class BusinessControllistingComponent implements OnInit {

  // constructor() { }
  constructor(private businessService: BusinessCtrlService) {
    this.loadBusinessList();
    //  constructor(public patientService:PatientService) {
    //this.loadPatientList();
  }
  ngOnInit() {
  }
  public getBusinessCtrlList: any[];
  
    loadBusinessList() {
      this.businessService.getBusinessCtrlList().subscribe(
        data => { this.getBusinessCtrlList = data },
        err => console.error(err),
        () => { }
      );
    }
}

