import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Headers, Response ,RequestOptions} from '@angular/http';
import { appConfig } from "../../../../core/config/app.config";
//import { appConfig } from "../../core/config/app.config";

@Component({
  selector: 'app-businessControl',
  templateUrl: './BusinessControl.component.html',
  styleUrls: ['./BusinessControl.component.css']
})


//app\professional\components\BusinessControl\Business Control Listing\BusinessControl-listing.component.html

export class BusinessControlComponent implements OnInit {
  BusinessForm: FormGroup;
  http:Http;
  headers:Headers;
    ngOnInit() {
      this.createForm();
    }
  
    private createForm() {
      this.BusinessForm = new FormGroup({
        
        // Name: new FormControl('', Validators.required),
        // Date: new FormControl('', Validators.required),
        
        PatientName:new FormControl('', Validators.required),
        AppointmentDate: new FormControl('', Validators.required),
        AppointmentTime:new FormControl('', Validators.required),
        ProfessionalAction :new  FormControl('', Validators.required),
        ProcedureType : new FormControl('', Validators.required),
        ActionFeedback : new FormControl('', Validators.required),
        CancellationDetails: new FormControl('', Validators.required),
      });
    }
 
    public check(){
      console.log(this.BusinessForm.value);
    }
// public save(){
//   console.log(this.BusinessForm.value);
//   //AddUpdateBuisnessControl
// }
public saveData(d:any){
  //  return this.http.post(appConfig.apiUrl+'api/Patient/AddUpdatePatient')
     return this.http.post(appConfig.apiUrl+`api/Patient/AddUpdatePatient`, JSON.stringify(d), { headers: this.headers })
    .map((res:Response) => res.json());
  }
    // public login() {
    //   console.log(this.loginForm.value);
    // }
  
  // constructor() { }

  // ngOnInit() {
  // }

}

