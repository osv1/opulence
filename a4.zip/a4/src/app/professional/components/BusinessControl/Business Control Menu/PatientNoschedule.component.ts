import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Headers, Response ,RequestOptions} from '@angular/http';
import { appConfig } from "../../../../core/config/app.config";
import { Router } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';
import {BusinessControlModel} from "./BusinessControllerInterface"
import { BusinessCtrlService } from "../../../businessCtrlServices/businessCtrlServices";

// import {User} from "./component/LoginUser";
  //import {NgbModule} from '@ng-bootstrap/ng-bootstrap'
  //import { ReactiveFormsModule } from '@angular/forms';

  // @Component({
//     selector: 'app-businessControl',
//     templateUrl: './BusinessControl.component.html',
//     styleUrls: ['./BusinessControl.component.css']
//    // BusinessCtrlService
//   })
  
  
  
  
  
  @Component({
      selector: 'app-patientNoschedule',
      templateUrl: './PatientNoschedule.component.html'
  })
  
  export class PatientNoScheduleComponent implements OnInit  {
    
    PatientNoScheduleForm: FormGroup;
        message: string;
        redirectUrl:string;
     
        constructor(public router: Router,private businessService: BusinessCtrlService) {
            debugger;
     
        }
    
        ngOnInit() {
          this.createForm();
        }
  
        private createForm() {
          this.PatientNoScheduleForm = new FormGroup({
            PatientName:new FormControl('', Validators.required),
            AppointmentDate: new FormControl('', Validators.required),
           // AppointmentTime:new FormControl('', Validators.required),
            //ProfessionalAction :new FormControl('', Validators.required),
           // ProcedureType : new FormControl('', Validators.required),
           // ActionFeedback : new FormControl('', Validators.required),
           // CancellationDetails: new FormControl('', Validators.required),
          });
        }
  
        save() {
                // let mdata = data.value;
                this.PatientNoScheduleForm.value.ProfessionalAction = "NO-SCHEDULE"; 
                let val = this.PatientNoScheduleForm.value;
                
               // let prop: BusinessControlModel;
                console.log(val);
                this.businessService.NoSchedulePatient(val).subscribe(
                  d => { this.router.navigate(['app/professional']) },
                  err => console.error(err),
                  () => { console.log("Done") }
                );
            
              }
    }
  
  
  
