import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Http, Headers, Response ,RequestOptions} from '@angular/http';
import { appConfig } from "../../../../core/config/app.config";
import { Router } from "@angular/router";
import { ReactiveFormsModule } from '@angular/forms';
import {BusinessControlModel} from "./BusinessControllerInterface"
import { BusinessCtrlService } from "../../../businessCtrlServices/businessCtrlServices";
 

// import {User} from "./component/LoginUser";
  //import {NgbModule} from '@ng-bootstrap/ng-bootstrap'
  //import { ReactiveFormsModule } from '@angular/forms';

 
  // @Component({
 
//     selector: 'app-businessControl',
//     templateUrl: './BusinessControl.component.html',
//     styleUrls: ['./BusinessControl.component.css']
//    // BusinessCtrlService
 
//   })
//   import {BusinessControlModel} from ;
   
//   })
  
  
  
  
  
  @Component({
      selector: 'app-businessClinicalProcedure',
      templateUrl: './BusinessControlClinicalProcedure.component.html'
  })
  
  export class BusinessCtrlClinicalProcedureComponent implements OnInit  {
    
    ClinicalProcedureForm: FormGroup;
        message: string;
        redirectUrl:string;
     
        constructor(public router: Router,private businessService: BusinessCtrlService) {
            debugger;
     
        }
    
        ngOnInit() {
          this.createForm();
        }
  
        private createForm() {
          this.ClinicalProcedureForm = new FormGroup({
            PatientName:new FormControl('', Validators.required),
            AppointmentDate: new FormControl('', Validators.required),
            AppointmentTime:new FormControl('', Validators.required),
            ProfessionalAction :new FormControl('', Validators.required),
           ProcedureType : new FormControl('', Validators.required),
           // ActionFeedback : new FormControl('', Validators.required),
           // CancellationDetails: new FormControl('', Validators.required),
          });
        }
  public  save() {
               
                this.ClinicalProcedureForm.value.ProfessionalAction = "Clinical Procedure"; 
                let val = this.ClinicalProcedureForm.value;
               
                console.log(val);
                this.businessService.ClinicalProcedure(val).subscribe(
                  d => { this.router.navigate(['app/professional']) },
                  err => console.error(err),
                  () => { console.log("Done") }
                );
            
              }
              
     
    }
  
  
  
 
