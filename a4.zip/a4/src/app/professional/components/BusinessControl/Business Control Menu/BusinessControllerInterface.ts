export interface BusinessControlModel{

    PatientName:string,
    AppointmentDate: Date,
    AppointmentTime:Date,
    ProfessionalAction :string,
    ProcedureType : string,
    ActionFeedback : string,
    CancellationDetails: string,
}