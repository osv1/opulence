import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsupplement',
  templateUrl: './addsupplement.component.html',
  styleUrls: ['./addsupplement.component.css']
})
export class AddsupplementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
