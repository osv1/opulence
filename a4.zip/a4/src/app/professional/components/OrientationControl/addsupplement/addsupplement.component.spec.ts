import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddsupplementComponent } from './addsupplement.component';

describe('AddsupplementComponent', () => {
  let component: AddsupplementComponent;
  let fixture: ComponentFixture<AddsupplementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddsupplementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddsupplementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
