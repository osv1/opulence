import { Injectable,Inject } from '@angular/core';
import { Http, Headers, Response ,RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';

import 'rxjs/add/operator/map'
import { appConfig } from "../../core/config/app.config";
 
@Injectable()
// export class AuthService {
//     redirectUrl: string;
//     isLoggedIn = false;

//     constructor(private http: Http) {debugger; }

//     login(): Observable<boolean> {
//         debugger;
//         return Observable.of(true).delay(1000).do(val => this.isLoggedIn = true);
//     }

//     logout(): void {
//         this.isLoggedIn = false;
//     }
// }
 
@Injectable()
export class AuthService {
    isLoggedIn = false;
    redirectUrl: string;
    public token: string;
     public headers:Headers;
 
    constructor( @Inject(Http) public http: Http) {
        // set token if saved in local storage
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.token = currentUser && currentUser.token;
        
    }
 
    login(formdata:any){
        
        debugger;
        let headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded' });
        let options = new RequestOptions({ headers: headers });
        //var data="grant_type=password&username=" + "patient@yopmail.com" + "&password=" + "Password@123";
        var data="grant_type=password&username=" + formdata.UserName + "&password=" + formdata.Password;
         return this.http.post( appConfig.apiUrl +'token', data,options)
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                debugger;
                let token = response.json() && response.json().access_token;
                if (token!=null && token!="") {
                    // set token property
                    this.token = token;
                    this.isLoggedIn = true;
                    // store username and jwt token in local storage to keep user logged in between page refreshes
                    //localStorage.setItem('currentUser', JSON.stringify({ username: applicationUser.Email, token: token }));
                    localStorage.setItem('currentUser', JSON.stringify({ token: token }));
                    // return true to indicate successful login
                    return true;
                } else {
                    // return false to indicate failed login
                    return false;
                }
            });
    }
 
    logout(): void {
        debugger;
        // clear token remove user from local storage to log user out
        this.token = null;
        localStorage.removeItem('currentUser');
    }
}